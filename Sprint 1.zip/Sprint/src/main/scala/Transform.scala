import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.sql.functions._

object ETLTransform {

  def transform(df: DataFrame): (DataFrame, DataFrame) = {
    val spark = df.sparkSession

    if (!df.columns.contains("ts_utc")) {
      throw new IllegalArgumentException("No timestamp column found. Found: " + df.columns.mkString(", "))
    }

    val parsedDF = df.withColumn("ts_utc_parsed", to_timestamp(col("ts_utc"), "dd-MM-yyyy HH:mm"))
    val badTsCount = parsedDF.filter(col("ts_utc_parsed").isNull).count()
    if (badTsCount > 0) {
      println(s"Warning: $badTsCount rows have invalid timestamps and will be dropped.")
    }

    val validDF = parsedDF.filter(col("ts_utc_parsed").isNotNull)
    val cleanedDF = validDF.withColumn("ts_utc", col("ts_utc_parsed")).drop("ts_utc_parsed")

    val numericCols = Seq(
      "energy_generated_kwh", "energy_consumed_kwh",
      "carbon_emissions_kgco2", "network_traffic_volume",
      "intrusion_attempt_frequency", "system_anomaly_score"
    )

    val castedDF = numericCols.foldLeft(cleanedDF) { (tempDF, colName) =>
      if (tempDF.columns.contains(colName)) {
        tempDF.withColumn(colName, col(colName).cast("double"))
      } else tempDF
    }

    val hourlyDF = castedDF.withColumn("hour_utc", date_trunc("hour", col("ts_utc")))

    val aggExprs = Seq(
      if (hourlyDF.columns.contains("energy_generated_kwh")) Some(sum("energy_generated_kwh").alias("total_generated_kwh")) else None,
      if (hourlyDF.columns.contains("energy_consumed_kwh")) Some(sum("energy_consumed_kwh").alias("total_consumed_kwh")) else None,
      if (hourlyDF.columns.contains("carbon_emissions_kgco2")) Some(avg("carbon_emissions_kgco2").alias("avg_carbon_emissions")) else None,
      if (hourlyDF.columns.contains("network_traffic_volume")) Some(avg("network_traffic_volume").alias("avg_network_traffic")) else None,
      if (hourlyDF.columns.contains("intrusion_attempt_frequency")) Some(sum("intrusion_attempt_frequency").alias("intrusion_attempts_sum")) else None,
      if (hourlyDF.columns.contains("system_anomaly_score")) Some(avg("system_anomaly_score").alias("anomaly_score_avg")) else None
    ).flatten

    val aggregatedDF = hourlyDF.groupBy("hour_utc").agg(aggExprs.head, aggExprs.tail: _*)

    val withNetBalance = if (aggregatedDF.columns.contains("total_generated_kwh") && aggregatedDF.columns.contains("total_consumed_kwh")) {
      aggregatedDF.withColumn("net_balance_kwh", col("total_generated_kwh") - col("total_consumed_kwh"))
    } else {
      aggregatedDF.withColumn("net_balance_kwh", lit(null).cast("double"))
    }

    val finalHourlyDF = if (withNetBalance.columns.contains("anomaly_score_avg")) {
      withNetBalance.withColumn("anomaly_flag", col("anomaly_score_avg") > 0.7)
    } else {
      withNetBalance.withColumn("anomaly_flag", lit(false))
    }

    (castedDF, finalHourlyDF)
  }

  // ✅ Add this to enable the green Run button
  def main(args: Array[String]): Unit = {
    val spark = SparkSession.builder
      .appName("ETL-Transform")
      .master("local[*]")
      .getOrCreate()

    val df = ETLExtract.extractCSV(spark)
    val (cleanedDF, hourlyDF) = transform(df)

    cleanedDF.show()
    hourlyDF.show()

    // Step 2: Define PostgreSQL connection

    val jdbcTableCleaned = "cleaned_data"
    val jdbcTableHourly = "hourly_summary"

    val jdbcUrl = "jdbc:postgresql://localhost:5432/postgres"
    val connectionProperties = new java.util.Properties()
    connectionProperties.setProperty("user", "postgres")//give your user
    connectionProperties.setProperty("password", "211100")//give your password
    connectionProperties.setProperty("driver", "org.postgresql.Driver")

    // Step 3: Write DataFrames to PostgreSQL
    cleanedDF.write
      .mode("overwrite") // or "append"
      .jdbc(jdbcUrl, jdbcTableCleaned, connectionProperties)

    hourlyDF.write
      .mode("overwrite")
      .jdbc(jdbcUrl, jdbcTableHourly, connectionProperties)

  }
}