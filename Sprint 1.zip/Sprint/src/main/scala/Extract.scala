import org.apache.spark.sql.{SparkSession, DataFrame}
import scala.util.matching.Regex

object ETLExtract {

  def normalizeColName(s: String): String = {
    if (s == null) return ""
    val trimmed = s.trim.toLowerCase
    val replaced = trimmed.replaceAll("\\W+", "_")
    replaced.stripPrefix("_").stripSuffix("_")
  }

  def extractCSV(spark: SparkSession, filePath: String = "../data/renewable_cyber_defense_dataset.csv"): DataFrame = {
    val df = spark.read
      .option("header", "true")
      .option("inferSchema", "false")
      .csv(filePath)

    val newCols = df.columns.map(normalizeColName)
    val renamedDF = df.columns.zip(newCols).foldLeft(df) {
      case (tempDF, (oldName, newName)) => tempDF.withColumnRenamed(oldName, newName)
    }

    val cleanedDF = renamedDF.drop(renamedDF.columns.filter(c => c == "" || c.startsWith("unnamed")): _*)

    val finalDF = if (cleanedDF.columns.contains("timestamp"))
      cleanedDF.withColumnRenamed("timestamp", "ts_utc")
    else if (cleanedDF.columns.contains("time"))
      cleanedDF.withColumnRenamed("time", "ts_utc")
    else if (cleanedDF.columns.contains("date"))
      cleanedDF.withColumnRenamed("date", "ts_utc")
    else
      cleanedDF

    finalDF
  }

  def main(args: Array[String]): Unit = {
    val spark = SparkSession.builder
      .appName("ETL-Extract")
      .master("local[*]") // ✅ Added to fix Spark master URL error
      .getOrCreate()

    val df = extractCSV(spark)
    df.show()
  }
}